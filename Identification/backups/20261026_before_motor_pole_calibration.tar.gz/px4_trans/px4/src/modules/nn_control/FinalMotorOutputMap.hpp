/****************************************************************************
 *
 *   Copyright (c) 2026 PX4 Development Team. All rights reserved.
 *
 ****************************************************************************/

#pragma once

#include "ControllerTypes.hpp"

namespace final_motor_output_map
{

// The controller command domain remains unchanged so the identified LQI gains,
// motor observers, and upper/lower limits keep their original calibration.
// Both physical motor outputs are linearly limited to half of normalized full
// throttle at the final actuator-output boundary.
static constexpr float kDefaultMotorScale{0.5f};

inline void apply(ActuatorSetpoint &output)
{
	for (int motor = 0; motor < ActuatorSetpoint::kMotorCount; ++motor) {
		output.motors[motor] *= kDefaultMotorScale;
	}
}

} // namespace final_motor_output_map
